<?php

class Config {

	var $sitename = "WP.test";
	var $address = "http://WP.test/";
	var $secret = "ad48n8asd";
	var $host = "localhost";
	var $db = "blog_testWP";
	var $user_db = "root";
	var $password_db = "";

}

?>